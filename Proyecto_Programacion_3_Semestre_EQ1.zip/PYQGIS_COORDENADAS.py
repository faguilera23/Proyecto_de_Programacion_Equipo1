from qgis.core import *
from qgis.gui import *
import PyQt5.QtGui
import PyQt5.QtCore
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from qgis.core import *

#lienzo Raster y vectorial
Colima = r'''C:\Users\FRANCISCO\OneDrive\Escritorio\Francisco- 5.10\PACO\B5.TIF'''
fileInfo = QFileInfo(Colima)
baseName = fileInfo.baseName()
rlayer = QgsRasterLayer(Colima, baseName)

QgsProject.instance().addMapLayer(rlayer)

#lienzo Raster y vectorial
Colima = r'''C:\Users\FRANCISCO\Downloads\Municipios_Colima\Municipios_Colima_UTM.shp'''
fileInfo = QFileInfo(Colima)
baseName = fileInfo.baseName()
vlayer = QgsVectorLayer(Colima, baseName)

QgsProject.instance().addMapLayer(vlayer)

#lienzo Raster y vectorial
Colima = r'''C:\Users\FRANCISCO\OneDrive\Escritorio\Proyecto_3_Semestre_EQ1\Coordenadas_UTM.shp'''
fileInfo = QFileInfo(Colima)
baseName = fileInfo.baseName()
vlayer = QgsVectorLayer(Colima, baseName)

QgsProject.instance().addMapLayer(vlayer)